<template>


  <table class="table">
    <thead class="thead-dark">
    <tr>
      <th scope="col">NIK</th>
      <th scope="col">ID TRANSAKSI</th>
      <th scope="col">ID RUMAH</th>
      <th scope="col">HARGA</th>
      <th scope="col">Tanggal Transaksi</th>
      <th scope="col>">tipe rumah</th>

    </tr>
    </thead>
    <tbody>
    <tr>

      <td>2147483647</td>
      <td>3</td>
      <td>101</td>
      <td>200000000</td>
      <td>2022-06-27</td>
      <td>36</td>
    </tr>
    </tbody>
  </table>
</template>